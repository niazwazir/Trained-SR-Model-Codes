function [im_h,layerout] = ILSR3x_inception(model, im_b)

%% load CNN model parameters
load(model);

%inception1 load
[in_conv1_patchsize2,in_conv1_filters] = size(in_weights_conv1);
in_conv1_patchsize = sqrt(in_conv1_patchsize2); 
[in_conv2_patchsize2,in_conv2_filters] = size(in_weights_conv2);
in_conv2_patchsize = sqrt(in_conv2_patchsize2);
[in_conv3_patchsize2,in_conv3_filters] = size(in_weights_conv3);
in_conv3_patchsize = sqrt(in_conv3_patchsize2);

%conv2
[conv2_channels,conv2_patchsize2,conv2_filters] = size(weights_conv2);
conv2_patchsize = sqrt(conv2_patchsize2);
%conv22
[conv22_channels,conv22_patchsize2,conv22_filters] = size(weights_conv22);
conv22_patchsize = sqrt(conv22_patchsize2);
%conv23
[conv23_channels,conv23_patchsize2,conv23_filters] = size(weights_conv23);
conv23_patchsize = sqrt(conv23_patchsize2);

%inception3 load
[in3_conv1_channels, in3_conv1_patchsize2,in3_conv1_filters] = size(in3_weights_conv1);
in3_conv1_patchsize = sqrt(in3_conv1_patchsize2); 
[in3_conv2_channels, in3_conv2_patchsize2,in3_conv2_filters] = size(in3_weights_conv2);
in3_conv2_patchsize = sqrt(in3_conv2_patchsize2);
[in3_conv3_channels, in3_conv3_patchsize2,in3_conv3_filters] = size(in3_weights_conv3);
in3_conv3_patchsize = sqrt(in3_conv3_patchsize2);

%conv3
[conv3_channels,conv3_patchsize2] = size(weights_conv3);
conv3_patchsize = sqrt(conv3_patchsize2);

[hei, wid] = size(im_b);

%% inception1
counter=1;
in_conv_data = zeros(hei, wid, in_conv1_filters+in_conv2_filters+in_conv3_filters);

in_weights_conv1 = reshape(in_weights_conv1, in_conv1_patchsize, in_conv1_patchsize, in_conv1_filters);
for i = 1 : in_conv1_filters
    in_conv_data(:,:,counter) = imfilter(im_b, in_weights_conv1(:,:,i), 'same', 'replicate');
    in_conv_data(:,:,counter) = max(in_conv_data(:,:,counter) + in_biases_conv1(i), 0);
    counter=counter+1;
end

in_weights_conv2 = reshape(in_weights_conv2, in_conv2_patchsize, in_conv2_patchsize, in_conv2_filters);
for i = 1 : in_conv2_filters
    in_conv_data(:,:,counter) = imfilter(im_b, in_weights_conv2(:,:,i), 'same', 'replicate');
    in_conv_data(:,:,counter) = max(in_conv_data(:,:,counter) + in_biases_conv2(i), 0);
    counter=counter+1;
end

in_weights_conv3 = reshape(in_weights_conv3, in_conv3_patchsize, in_conv3_patchsize, in_conv3_filters);
for i = 1 : in_conv3_filters
    in_conv_data(:,:,counter) = imfilter(im_b, in_weights_conv3(:,:,i), 'same', 'replicate');
    in_conv_data(:,:,counter) = max(in_conv_data(:,:,counter) + in_biases_conv3(i), 0);
    counter=counter+1;
end

%layerout=in_conv_data;

%% conv2
conv2_data = zeros(hei, wid, conv2_filters);
for i = 1 : conv2_filters
    for j = 1 : conv2_channels
        conv2_subfilter = reshape(weights_conv2(j,:,i), conv2_patchsize, conv2_patchsize);
        conv2_data(:,:,i) = conv2_data(:,:,i) + imfilter(in_conv_data(:,:,j), conv2_subfilter, 'same', 'replicate');
    end
    conv2_data(:,:,i) = max(conv2_data(:,:,i) + biases_conv2(i), 0);
end

%layerout=conv2_data;

%% conv22
conv22_data = zeros(hei, wid, conv22_filters);
for i = 1 : conv22_filters
    for j = 1 : conv22_channels
        conv22_subfilter = reshape(weights_conv22(j,:,i), conv22_patchsize, conv22_patchsize);
        conv22_data(:,:,i) = conv22_data(:,:,i) + imfilter(conv2_data(:,:,j), conv22_subfilter, 'same', 'replicate');
    end
    conv22_data(:,:,i) = max(conv22_data(:,:,i) + biases_conv22(i), 0);
end

%layerout=conv22_data;

%% conv23
conv23_data = zeros(hei, wid, conv23_filters);
for i = 1 : conv23_filters
    for j = 1 : conv23_channels
        conv23_subfilter = reshape(weights_conv23(j,:,i), conv23_patchsize, conv23_patchsize);
        conv23_data(:,:,i) = conv23_data(:,:,i) + imfilter(conv22_data(:,:,j), conv23_subfilter, 'same', 'replicate');
    end
    conv23_data(:,:,i) = max(conv23_data(:,:,i) + biases_conv23(i), 0);
end

layerout=conv23_data;

%% inception3
counter=1;
in3_conv_data = zeros(hei, wid, in3_conv1_filters+in3_conv2_filters+in3_conv3_filters);

for i = 1 : in3_conv1_filters
    for j = 1 : in3_conv1_channels
        in3_conv1_subfilter = reshape(in3_weights_conv1(j,:,i), in3_conv1_patchsize, in3_conv1_patchsize);
        in3_conv_data(:,:,counter) = in3_conv_data(:,:,counter) + imfilter(conv23_data(:,:,j), in3_conv1_subfilter, 'same', 'replicate');
    end
    in3_conv_data(:,:,counter) = max(in3_conv_data(:,:,counter) + in3_biases_conv1(i), 0);
    counter=counter+1;
end

% inception_conv2
for i = 1 : in3_conv2_filters
    for j = 1 : in3_conv2_channels
        in3_conv2_subfilter = reshape(in3_weights_conv2(j,:,i), in3_conv2_patchsize, in3_conv2_patchsize);
        in3_conv_data(:,:,counter) = in3_conv_data(:,:,counter) + imfilter(conv23_data(:,:,j), in3_conv2_subfilter, 'same', 'replicate');
    end
    in3_conv_data(:,:,counter) = max(in3_conv_data(:,:,counter) + in3_biases_conv2(i), 0);
    counter=counter+1;
end

% inception_conv3
for i = 1 : in3_conv3_filters
    for j = 1 : in3_conv3_channels
        in3_conv3_subfilter = reshape(in3_weights_conv3(j,:,i), in3_conv3_patchsize, in3_conv3_patchsize);
        in3_conv_data(:,:,counter) = in3_conv_data(:,:,counter) + imfilter(conv23_data(:,:,j), in3_conv3_subfilter, 'same', 'replicate');
    end
    in3_conv_data(:,:,counter) = max(in3_conv_data(:,:,counter) + in3_biases_conv3(i), 0);
    counter=counter+1;
end

%layerout=in3_conv_data;

%% conv3
conv3_data = zeros(hei, wid);
for i = 1 : conv3_channels
    conv3_subfilter = reshape(weights_conv3(i,:), conv3_patchsize, conv3_patchsize);
    conv3_data(:,:) = conv3_data(:,:) + imfilter(in3_conv_data(:,:,i), conv3_subfilter, 'same', 'replicate');
end

%% DRLSR reconstruction
im_h = im_b+conv3_data(:,:) + biases_conv3;